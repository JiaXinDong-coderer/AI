Run under Python 3.8.7

If you want more time to test a case please change the thresh in endLong() function
the reasonable time I choose is 65 seconds

both easy case can search with my algorithm and both hard cases are not solvable for mine algorithm